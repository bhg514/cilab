#pragma once

#include <Wire.h>
#include "Arduino.h"


class i2c_com
{
  public:

    static void initialize();
    static uint8_t read8(uint8_t add, uint8_t reg);
    static bool readbuf(uint8_t add, uint8_t reg, uint8_t * buffer, uint8_t len);
    static bool write8(uint8_t add, uint8_t reg, uint8_t value);
    static bool write(uint8_t add, uint8_t reg);
    
};
