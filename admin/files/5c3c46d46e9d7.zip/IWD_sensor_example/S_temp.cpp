#include "S_temp.h"

namespace S_temp
{
uint16_t C[8];
uint8_t buf[3];
uint32_t D1;
uint32_t adc;

void Initialize()
{
  i2c_com::write(0x77, 0x1E);
  delay(10);
  for ( uint8_t i = 0 ; i < 8 ; i++ )
  {
    i2c_com::readbuf(0x77, 0xA0 + (i * 2), buf, 2);
    C[i] = (buf[0] << 8) | buf[1];
  }
}

void Gettemp(double &t)
{
  i2c_com::write(0x77, 0x48);
  delay(10);
  i2c_com::readbuf(0x77, 0x00, buf, 3);
  D1 = 0;
  D1 = buf[0];
  D1 = (D1 << 8) | buf[1];
  D1 = (D1 << 8) | buf[2];

  adc = D1 / 256;

  t = (-2) * float(C[1]) / 1000000000000000000000.0f * pow(adc, 4) +
      4 * float(C[2]) / 10000000000000000.0f * pow(adc, 3) +
      (-2) * float(C[3]) / 100000000000.0f * pow(adc, 2) +
      1 * float(C[4]) / 1000000.0f * adc +
      (-1.5) * float(C[5]) / 100 ;

}
}

