#include"i2c_com.h"

namespace S_temp
{
// Methods
extern void Initialize();
extern void Gettemp(double &t);
}
